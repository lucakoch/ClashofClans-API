# Clash-of-Clans-API

This is an easy to use API for the game Clash of Clans

## Disclaimer
This content is not affiliated with, endorsed, sponsored, or specifically approved by Supercell and Supercell is not responsible for it.
For more information see Supercell’s Fan Content Policy: www.supercell.com/fan-content-policy.